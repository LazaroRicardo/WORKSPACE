package com.ricardo.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ricardo.models.Role;
import com.ricardo.persistencia.RolManager;

public class RolServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.getRequestDispatcher("/rol.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nombre = request.getParameter("nombre");
		String descripcion = request.getParameter("descripcion");
		
		try {
			Role unRole = new Role(0, nombre, descripcion);
			int roletename = RolManager.getInstance().createRol(unRole);
			request.setAttribute("nuevoRol", roletename);
			request.setAttribute("Mensaje", "Rol creado!");
			
		} catch (Exception e) {
			request.setAttribute("error", "ha habido un error...");
			System.out.println("Exception:"+e);
		}
		
		doGet(request, response);
	}

}
