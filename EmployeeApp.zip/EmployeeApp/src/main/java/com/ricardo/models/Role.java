package com.ricardo.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//vamos a hacer este modelo diferente a Employee usando anotaciones:
//coger el "entity" y "table" de java persistens:
@Entity
@Table(name = "rol")

public class Role {

	// identificar que el id es una clave primaria con @id:
	@Id
	// el modo de generar el valor sea autoincrementado usando esto::
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	// las otras dos propiedades son columnas:
	@Column
	private String nombre;
	@Column
	private String descripcion;

	public Role(int id, String nombre, String descripcion) {

		this.id = id;
		this.nombre = nombre;
		this.descripcion = descripcion;
	}

	//el construcot vacio lo necesita la bd para generar automaticamente los valores del modelo:
	public Role() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
