package com.ricardo.models;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.BeforeClass;
import org.junit.Test;

public class EmployeeTest {

	private static SessionFactory sf = null;

	@BeforeClass
	public static void createSessionFactory() {
		sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	}

	// factory patron de dise�o que crea objetos sdin necesidad de hacerlos:
	@Test
	public void testSession() {
		Session session = sf.openSession();
		assertNotNull(session);
	}

	//hibernate lee la configuracion y lee los SessionFactory para crear las tablas:
	@Test
	public void testInsert() {
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();

		// para hacer insert de nuevo empleado:
		Employee newE = new Employee(0, "Pepe", "Perez");
		int id = ((Integer) session.save(newE)).intValue();
		System.out.println("El ide nuevo es:" + id);

		Employee newE2 = new Employee(0, "Maria", "Martinez");
		session.save(newE2);

		Employee newE3 = new Employee(0, "Julia", "Juarez");
		session.save(newE3);

		t.commit();
		session.close();

	}

	@Test
	public void testGet() {
		Session session = sf.openSession();

		Employee recE = session.get(Employee.class, 3);
		System.out.println("empleado recibido:" + recE.getNombre());

		session.close();
	}

	@Test
	public void testLoad() {
		Session session = sf.openSession();
//para ver todo lo que se encuentra en bbdd
		List<Employee> empleados=  session.createQuery("from Employee WHERE id>5", Employee.class).getResultList();

		for (Employee employee : empleados) {
			System.out.println("Empleados:"+employee.getId());
		}
		
		System.out.println("Empleados:"+empleados);
		
		session.close();
	}

	@Test
	public void testDelet() {
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		
		Employee empleadinho = new Employee(8, "", "");
		session.delete(empleadinho);
		System.out.println("Empleado borrado:"+empleadinho);
		t.commit();
		session.close();
	}
	
	@Test
	public void testUpdate() {
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		
		Employee empleadinho = new Employee(2, "Juano", "Banano");
		session.update(empleadinho);
		System.out.println("Empleado editado:"+empleadinho);
		t.commit();
		session.close();
	}
	
}
